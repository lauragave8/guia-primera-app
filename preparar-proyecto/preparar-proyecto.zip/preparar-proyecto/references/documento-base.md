# Guía para el documento base

Usa esta guía al resumir o entregar el proyecto. Organiza las decisiones, no la transcripción. Combina o reduce apartados para una petición pequeña y amplía solo lo necesario. Sustituye las indicaciones por contenido; identifica pendientes útiles sin dejar un formulario vacío.

## Entrega al cerrar la entrevista

El límite de cinco preguntas no reduce el entregable a un resumen. Incluye las decisiones conocidas, ejemplos concretos para comprobarlas y lo que falta resolver. No prolongues la conversación para llenar apartados o pedir permiso para generar el archivo.

En el estado del documento, distingue una preparación revisada de un borrador con decisiones esenciales abiertas. Registra pendientes aunque la persona haya aprobado el resto; completar el documento no prueba el funcionamiento de una app.

## Encabezado y propósito

Nombre del proyecto y estado: revisado con la persona o borrador con decisiones pendientes. Indica si se prepara una maqueta, una versión funcional o una mejora integrada.

Resume para quién es, qué necesidad atiende, de qué se parte y cuál es el resultado útil. Distingue lo que se ha observado de lo relatado y de lo no revisado.

## Primera versión

Describe el recorrido que se podrá completar y las capacidades necesarias. Indica qué se conserva en una mejora y las ideas que quedan para después. No atribuyas exclusiones o nuevas funciones a la persona sin haberlas decidido.

Registra condiciones relevantes de uso, dispositivos, tiempo, presupuesto o herramientas. Mantén propuestas y decisiones delegadas identificables.

## Reglas y datos

Expresa comportamientos concretos. Identifica el origen y significado de los datos, qué debe guardarse o recuperarse y las condiciones que cambian el recorrido.

Señala junto a cada decisión lo confirmado, propuesto o pendiente cuando pueda haber confusión. Los datos ficticios se identifican como ejemplos. No elijas almacenamiento, arquitectura o integraciones sin respaldo en lo conversado.

## Comprobaciones previstas

Relaciona las reglas esenciales con ejemplos observables. Una tabla posible:

| Regla o decisión | Situación inicial | Acción | Resultado esperado |
|---|---|---|---|

Describe suficientes casos para distinguir el comportamiento pedido de alternativas posibles. No conviertas esta preparación en un paquete obligatorio de pruebas automatizadas.

Aclara cuáles son comprobaciones previstas y cuáles se han ejecutado realmente. Para una prueba realizada, indica resultado y evidencia. Una regla todavía pendiente no puede presentarse como un criterio aprobado.

## Referencias y materiales

Por cada material, registra su nombre/enlace, qué se pudo revisar y qué aspecto orienta. Separa inspiración de material que formará parte del resultado.

Lista los archivos que deben adjuntarse otra vez al cambiar de sesión. No dependas de rutas internas del entorno para que otra persona pueda continuar.

## Pendientes y continuación

Indica qué falta decidir o revisar, qué parte afecta y si puede avanzar algo entretanto. Explica el siguiente paso realizable.

Cierra con una instrucción de continuación adaptada, por ejemplo:

> Usa este documento y los materiales adjuntos para construir la primera versión descrita. Empieza por el siguiente paso. Resuelve los pendientes que afecten esa parte antes de implementarla y comprueba los resultados previstos.

El documento puede estar revisado y conservar pendientes técnicos. No afirmar que el proyecto funciona por haber terminado la entrevista.
