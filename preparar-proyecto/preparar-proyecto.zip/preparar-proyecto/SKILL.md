---
name: preparar-proyecto
description: Define proyectos nuevos o mejoras de apps, webs y automatizaciones con hasta 5 preguntas; entrega un documento con primera versión, reglas, comprobaciones y pendientes para construir con IA.
---

# Prepara tu proyecto

Acompaña a la persona desde una idea hasta una primera versión definida, mediante una entrevista de hasta cinco preguntas y una entrega concreta. El resultado es un documento que conserva sus decisiones y permite reconocer si lo construido cumple lo que quería. Funciona para proyectos nuevos y mejoras, incluso cuando la persona no sabe programar.

## Recupera el contexto y el resultado buscado

Lee lo ya explicado y los materiales disponibles. Aprovecha las decisiones existentes; identifica cuáles siguen abiertas. Distingue lo observado, lo relatado y lo que falta revisar.

Determina si se busca una demostración visual, una versión funcional o una modificación integrada en algo existente cuando esa diferencia afecte la preparación. Una captura puede orientar la apariencia; para una integración hace falta conocer la parte pertinente del proyecto. Examina los materiales disponibles; si no tienes acceso al proyecto, conserva esa revisión como siguiente paso.

La preparación no inicia automáticamente la implementación. Las herramientas y la profundidad dependen del proyecto y del entorno disponible.

## Entrevista con un máximo de cinco preguntas

El límite es **cinco preguntas en total**, incluida la revisión final. Es un máximo, no una cuota que haya que llenar. Solo cambia este número si la persona pide expresamente otro.

Antes de empezar, usa la petición, lo ya conversado y los materiales para identificar lo confirmado y ordenar los vacíos por su efecto. Cuenta las preguntas de esta misma entrevista que ya aparecen en una conversación retomada; cargar estas instrucciones no reinicia el presupuesto. Si no se conoce un tramo anterior, señala ese límite sin inventar un contador.

- Reserva una pregunta para la revisión del resumen. Usa como máximo cuatro para descubrir decisiones.
- En cada turno, solicita **una decisión** y espera la respuesta. Muestra “Pregunta n/5”. Una aclaración o petición de material que requiere respuesta también consume una pregunta; no escondas varias decisiones bajo una sola frase.
- No repitas información ya dada. Una respuesta puede cubrir varios asuntos: incorpora todos sus datos sin volver a preguntarlos.
- Prioriza dudas que cambian el resultado, el recorrido, los datos o una regla esencial. Las referencias, preferencias menores y elecciones técnicas que necesitan revisar código pueden quedar documentadas sin gastar otra pregunta.
- Si la persona no sabe elegir, explica dos o tres alternativas brevemente y recomienda una. La falta de respuesta concreta no abre automáticamente otra ronda: conserva la elección como propuesta, o resuélvela si fue delegada expresamente.
- Usa los ejemplos para explicar la decisión actual, no para añadir preguntas. Las preguntas que resuelven contradicciones forman parte del mismo límite.

Cuando haya suficiente claridad, pasa a la revisión antes de gastar las cuatro preguntas de descubrimiento. Si ya usaste cuatro, la siguiente respuesta debe ser el resumen y la pregunta de revisión; no un nuevo requisito, una segunda lista de materiales o un cuestionario.

Si la persona pide el documento antes, omite el resto de la entrevista y entrégalo con su estado real.

## Deja cuatro resultados útiles

### 1. Reglas que cambian el comportamiento

Describe un recorrido concreto: qué hace o introduce la persona, qué ocurre y qué recibe. En una automatización, identifica qué la inicia y dónde llega la salida.

Resuelve las ambigüedades relevantes de ese recorrido. Expresa cada regla esencial como una relación entre condición o acción y resultado, en lenguaje cotidiano. No basta con términos como “bien”, “fácil” o “rápido” si determinan la aceptación: concreta qué se podrá observar.

Cuando corresponda, aclara el origen y significado de los datos, qué debe conservarse y qué ocurre si falta información. No inventes historial, disponibilidad, integraciones o funcionamiento a partir de una imagen. Los ejemplos y las reglas pertenecen al proyecto real; no impongas casos de un proyecto a los demás.

### 2. Primera versión acotada

Define el resultado útil que se quiere conseguir primero y las capacidades necesarias para completar ese recorrido. Registra por separado ideas para después, cuando existan.

Si una propuesta amplía el alcance, explica cómo cambia el trabajo y conserva su estado hasta que se adopte. El tiempo, presupuesto, dispositivos o herramientas se aclaran cuando afecten esa elección. No obligues a elegir una tecnología antes de entender la necesidad.

En una mejora, identifica qué ya existe, qué debe conservarse y qué se cambia. Si un dato técnico sigue abierto, explica qué exploración lo resolverá y qué parte puede avanzar.

### 3. Comprobaciones ligadas a lo pedido

Para las reglas esenciales, define ejemplos con **situación inicial → acción → resultado esperado**. La comprobación debe permitir juzgar el comportamiento, no limitarse a que “la app abre” o “se ve bien”.

Elige casos que distingan resultados posibles. Si la regla define qué se cuenta, utiliza un ejemplo que pueda cambiar el conteo; si exige conservar información, especifica cuándo se recupera y qué dato debería aparecer. Añade únicamente los casos adicionales que aporten al alcance.

Relaciona reglas y comprobaciones con identificadores cuando ayuden a revisar muchas decisiones; una tabla pequeña basta para proyectos simples. Etiqueta estas comprobaciones como previstas: preparar el proyecto no demuestra que un producto aún no construido funcione. Si existen pruebas realizadas, registra qué se observó y su evidencia.

### 4. Documento para continuar

Lee [references/documento-base.md](references/documento-base.md) al preparar el resumen o el documento. Usa su organización como guía y ajusta la extensión al proyecto.

Conserva lo confirmado, las propuestas y los pendientes junto a la decisión correspondiente. Incluye referencias y su función: apariencia, distribución, contenido, comportamiento o material que se incorporará. Una imagen no demuestra propiedades que no se observan.

Entrega el contenido completo y, si el entorno lo permite, un archivo llamado `documento-base-<proyecto>.md`. Si no puedes crear un archivo, da el texto organizado para copiar. Indica qué materiales habrá que adjuntar de nuevo; copiar el documento no transfiere los archivos originales ni concede acceso a ellos.

## Revisión final y entrega sin otra ronda

Revisa coherencia entre alcance, recorrido, reglas y comprobaciones. Presenta un resumen breve con decisiones confirmadas, propuestas y pendientes. Solicita **una revisión global**, dentro del límite: “¿Este resumen representa tu primera versión o qué corrección quieres hacer?”.

Después de la respuesta a esa revisión, incorpora las correcciones y entrega en el mismo turno el documento completo. La entrega cierra la entrevista: termina con el siguiente paso escrito, sin otra pregunta para seguir conversando. No añadas una sexta pregunta, otra aprobación, una pregunta para confirmar el nombre del archivo ni un ofrecimiento de generar el documento más tarde.

Si al retomar una entrevista ya se alcanzó el máximo, o la persona pide cerrar, entrega directamente. Los vacíos que queden se registran como pendientes con su efecto y el siguiente paso para resolverlos. Una corrección final que abra una contradicción se describe en el documento; no sirve para exceder el límite ni para inventar una decisión.

El documento debe contener las cuatro utilidades: primera versión, reglas, comprobaciones previstas y continuación. No lo reduzcas a un resumen por haber agotado las preguntas. Identifica como borrador lo que todavía no haya sido revisado o tenga una decisión esencial abierta; no afirmar que ya se puede implementar una parte bloqueada.

Entrega el archivo cuando sea posible y el contenido completo si no puedes crearlo. Explica brevemente qué materiales necesita la sesión de construcción. Las sugerencias y los pendientes conservan su estado hasta ser adoptados. La entrevista prepara el proyecto; una implementación o un plan técnico se realizan cuando se solicitan y hay información suficiente.
